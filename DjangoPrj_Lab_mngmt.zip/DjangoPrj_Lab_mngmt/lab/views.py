# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# import上层目录下的py文件，需要通过sys.path.append先索引到上层目录
# 在需索引到py文件目录下，要创建__init__.py文件，且每一级目录都要创建
import sys
sys.path.append("..")

import json

# 通过"."索引目录，一直索引到py文件名
from static.py.fusioncharts.fusioncharts import FusionCharts

from django.shortcuts import render, get_object_or_404, HttpResponseRedirect, reverse
from .models import USER_CHOICES, ClassicalBTS, Asik, Abil, Gps, Rru, Amia, Pb
from .forms import AsikForm, GpsForm, ClassicalBTSForm, AbilForm, RruForm, AmiaForm, PbForm
from collections import OrderedDict


# Create your views here.
# classicalbts view functions
def lab_classicalbts(request):
    classicalbtss = ClassicalBTS.objects.all()
    return render(request, "lab/classicalbtss.html", {"classicalbtss":classicalbtss})

def lab_classicalbts_detail_form(request, classicalbts_id):
    classicalbts_initial = get_object_or_404(ClassicalBTS, id=classicalbts_id)
    form = ClassicalBTSForm(request.POST or None, instance=classicalbts_initial)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:classicalbts"))
    return render(request, "lab/classicalbts_detail_form.html", {"classicalbts_form": form, "classicalbts_id": classicalbts_id})

def lab_classicalbts_delete(request, classicalbts_id):
    classicalbts = get_object_or_404(ClassicalBTS, id=classicalbts_id)
    classicalbts.delete()
    return HttpResponseRedirect(reverse("lab:classicalbts"))

def lab_classicalbts_add(request):
    classicalbts_form = ClassicalBTSForm()
    if request.method == "POST":
        classicalbts_form = ClassicalBTSForm(request.POST)
        if classicalbts_form.is_valid():
            classicalbts_form.save()
            return HttpResponseRedirect(reverse("lab:classicalbts"))
    return render(request, "lab/classicalbts_detail_form.html", {"classicalbts_form":classicalbts_form})


# asik view functions
def lab_asik(request):
    asiks = Asik.objects.all()
    return render(request, "lab/asiks.html", {"asiks":asiks})

def lab_asik_detail_form(request, asik_id):

    # 在 form = AsikFrom()定义时， 有两个参数，
    # initail  -- 如定义此参数，表明新数据插入到AsikForm对应的model中，新增数据
    # instance  -- 如定义此参数，不插入新数据，而是更新此model中到已有数据（通过id定位到数据）
    # 此函数是为了更新asik_id的数据，不是插入新数据，所以不用initail，而是instance
    # 错误： asik_initial = Asik.objects.filter(id = asik_id).values()[0]    form = AsikForm(initial=asik_initial)
    # 正确： asik_initial = get_object_or_404(Asik, id=asik_id)    form = AsikForm(request.POST or None, instance=asik_initial)
    asik_initial = get_object_or_404(Asik, id=asik_id)
    form = AsikForm(request.POST or None, instance=asik_initial)
    if form.is_valid():    # .is_valid做了很多事情，如果此步不通过，.cleaned_data会没有定义
        form.save()
        return HttpResponseRedirect(reverse("lab:asik"))
    return render(request, "lab/asik_detail_form.html", {"asik_form": form, "asik_id": asik_id})

def lab_asik_delete(request, asik_id):
    asik = get_object_or_404(Asik, id=asik_id)
    asik.delete()
    return HttpResponseRedirect(reverse("lab:asik"))

def lab_asik_add(request):
    asik_form = AsikForm()    # 未传入instance参数，则表明新增数据，插入model中。
    if request.method == "POST":
        asik_form = AsikForm(request.POST)
        if asik_form.is_valid():
            asik_form.save()
            return HttpResponseRedirect(reverse("lab:asik"))
    return render(request, "lab/asik_detail_form.html", {"asik_form":asik_form})


def lab_abil(request):
    abils = Abil.objects.all()
    return render(request, "lab/abils.html", {"abils":abils})

# gps view functions
def lab_gps(request):
    gpss = Gps.objects.all()
    return render(request, "lab/gpss.html", {"gpss": gpss})

def lab_gps_detail_form(request, gps_id):
    gps_instance = get_object_or_404(Gps, id=gps_id)
    form = GpsForm(request.POST or None, instance=gps_instance)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:gps"))
    return render(request, "lab/gps_detail_form.html", {"gps_form": form, "gps_id": gps_id})

def lab_gps_delete(request, gps_id):
    gps = get_object_or_404(Gps, id=gps_id)
    gps.delete()
    return HttpResponseRedirect(reverse("lab:gps"))

def lab_gps_add(request):
    gps_form = GpsForm()
    if request.method == "POST":
        gps_form = GpsForm(request.POST)
        if gps_form.is_valid():
            gps_form.save()
            return HttpResponseRedirect(reverse("lab:gps"))
    return render(request, "lab/gps_detail_form.html", {"gps_form":gps_form})

# abil view functions
def lab_abil(request):
    abils = Abil.objects.all()
    return render(request, "lab/abils.html", {"abils": abils})

def lab_abil_detail_form(request, abil_id):
    abil_instance = get_object_or_404(Abil, id=abil_id)
    form = AbilForm(request.POST or None, instance=abil_instance)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:abil"))
    return render(request, "lab/abil_detail_form.html", {"abil_form": form, "abil_id": abil_id})

def lab_abil_delete(request, abil_id):
    abil = get_object_or_404(Abil, id=abil_id)
    abil.delete()
    return HttpResponseRedirect(reverse("lab:abil"))

def lab_abil_add(request):
    abil_form = AbilForm()
    if request.method == "POST":
        abil_form = AbilForm(request.POST)
        if abil_form.is_valid():
            abil_form.save()
            return HttpResponseRedirect(reverse("lab:abil"))
    return render(request, "lab/abil_detail_form.html", {"abil_form":abil_form})

# rru view functions
def lab_rru(request):
    rrus = Rru.objects.all()
    return render(request, "lab/rrus.html", {"rrus": rrus})

def lab_rru_detail_form(request, rru_id):
    rru_instance = get_object_or_404(Rru, id=rru_id)
    form = RruForm(request.POST or None, instance=rru_instance)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:rru"))
    return render(request, "lab/rru_detail_form.html", {"rru_form": form, "rru_id": rru_id})

def lab_rru_delete(request, rru_id):
    rru = get_object_or_404(Rru, id=rru_id)
    rru.delete()
    return HttpResponseRedirect(reverse("lab:rru"))

def lab_rru_add(request):
    rru_form = RruForm()
    if request.method == "POST":
        rru_form = RruForm(request.POST)
        if rru_form.is_valid():
            rru_form.save()
            return HttpResponseRedirect(reverse("lab:rru"))
    return render(request, "lab/rru_detail_form.html", {"rru_form":rru_form})

# amia view functions
def lab_amia(request):
    amias = Amia.objects.all()
    return render(request, "lab/amias.html", {"amias": amias})

def lab_amia_detail_form(request, amia_id):
    amia_instance = get_object_or_404(Amia, id=amia_id)
    form = AmiaForm(request.POST or None, instance=amia_instance)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:amia"))
    return render(request, "lab/amia_detail_form.html", {"amia_form": form, "amia_id": amia_id})

def lab_amia_delete(request, amia_id):
    amia = get_object_or_404(Amia, id=amia_id)
    amia.delete()
    return HttpResponseRedirect(reverse("lab:amia"))

def lab_amia_add(request):
    amia_form = AmiaForm()
    if request.method == "POST":
        amia_form = AmiaForm(request.POST)
        if amia_form.is_valid():
            amia_form.save()
            return HttpResponseRedirect(reverse("lab:amia"))
    return render(request, "lab/amia_detail_form.html", {"amia_form":amia_form})

# pb view functions
def lab_pb(request):
    pbs = Pb.objects.all()
    return render(request, "lab/pbs.html", {"pbs": pbs})

def lab_pb_detail_form(request, pb_id):
    pb_instance = get_object_or_404(Pb, id=pb_id)
    form = PbForm(request.POST or None, instance=pb_instance)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect(reverse("lab:pb"))
    return render(request, "lab/pb_detail_form.html", {"pb_form": form, "pb_id": pb_id})

def lab_pb_delete(request, pb_id):
    pb = get_object_or_404(Pb, id=pb_id)
    pb.delete()
    return HttpResponseRedirect(reverse("lab:pb"))

def lab_pb_add(request):
    pb_form = PbForm()
    if request.method == "POST":
        pb_form = PbForm(request.POST)
        if pb_form.is_valid():
            pb_form.save()
            return HttpResponseRedirect(reverse("lab:pb"))
    return render(request, "lab/pb_detail_form.html", {"pb_form":pb_form})

def lab_objects_chart():

    #Chart data is passed to the `dataSource` parameter, like a dictionary in the form of key-value pairs.
    dataSource = OrderedDict()

    # The `chartConfig` dict contains key-value pairs of data for chart attribute
    chartConfig = OrderedDict()
    chartConfig["caption"] = "HOW RICH WE ARE?"
    chartConfig["subCaption"] = ""
    chartConfig["xAxisName"] = "Item"
    chartConfig["yAxisName"] = "Count"
    chartConfig["numberSuffix"] = ""
    chartConfig["theme"] = "ocean"    # 如果需要fusion，gammel candy zune ocean都生效，需要在html中导入相应到js文件

    # The `chartData` dict contains key-value pairs of data
    chartData = OrderedDict()
    chartData[ClassicalBTS.__name__] = ClassicalBTS.objects.count()
    chartData[Asik.__name__] = Asik.objects.count()
    chartData[Abil.__name__] = Abil.objects.count()
    chartData[Gps.__name__] = Gps.objects.count()
    chartData[Rru.__name__] = Rru.objects.count()
    chartData[Amia.__name__] = Amia.objects.count()
    chartData[Pb.__name__] = Pb.objects.count()

    dataSource["chart"] = chartConfig
    dataSource["data"] = []

    # Convert the data in the `chartData`array into a format that can be consumed by FusionCharts.
    #The data for the chart should be in an array wherein each element of the array
    #is a JSON object# having the `label` and `value` as keys.

    #Iterate through the data in `chartData` and insert into the `dataSource['data']` list.
    for key, value in chartData.items():
        data = {}
        data["label"] = key
        data["value"] = value
        dataSource["data"].append(data)

    # Create an object for the column 2D chart using the FusionCharts class constructor
    # The chart data is passed to the `dataSource` parameter.

    # FusionCharts 参数: (type, id, width, height, renderAt, dataFormat, dataSource)
    # rendAt要与.html中的<div id="myFirstchart-container1">{{ output1|safe }}</div> 保持一致，如果不一致，无法显示出来。
    # id 不需要和html中一致，但需要唯一，如不唯一，只能显示第一个

    lab_objects_chartObj = FusionCharts("column2d", "myFirstChart1", "600", "400", "lab_objects_chart", "json", dataSource)
    return lab_objects_chartObj

def lab_users_chart():

    dataSource = OrderedDict()

    chartConfig = OrderedDict()
    chartConfig["caption"] = "WHO ARE THE RICHEST?"
    chartConfig["subCaption"] = ""
    chartConfig["numbersuffix"] = ""
    chartConfig["showsum"] = "1"
    chartConfig["plottooltext"] = "<b>$label</b> has <b>$dataValue</b> pieces of <b>$seriesName</b>"
    chartConfig["theme"] = "ocean"
    chartConfig["drawcrossline"] = "1"
    chartConfig["numberSuffix"] = ""
    dataSource['chart'] = chartConfig

    categories = []
    category = []
    category_dict = OrderedDict()
    for i in range(len(USER_CHOICES)):
        user = {}
        user["label"] = USER_CHOICES[i][1]
        category.append(user)
    category_dict['category'] = category
    categories.append(category_dict)
    dataSource['categories'] = categories

    dataset = []
    asik_dataset = OrderedDict()
    asik_dataset['seriesname'] = Asik.__name__
    asik_data = []
    for i in range(len(USER_CHOICES)):
        value = {}
        value['value'] = Asik.objects.filter(owner=USER_CHOICES[i][1]).count()
        asik_data.append(value)
    asik_dataset['data'] = asik_data
    dataset.append(asik_dataset)

    abil_dataset = OrderedDict()
    abil_dataset['seriesname'] = Abil.__name__
    abil_data = []
    for i in range(len(category)):
        value = {}
        value['value'] = Abil.objects.filter(owner=category[i]).count()
        abil_data.append(value)
    abil_dataset['data'] = abil_data
    dataset.append(abil_dataset)
    dataSource['dataset'] = dataset

    # print(json.dumps(dataSource, indent=4))  # 将OrderedDict按照json格式打印

    lab_users_chartObj = FusionCharts("stackedcolumn2d", "ex1", "800", "500", "lab_users_chart", "json", dataSource)
    return lab_users_chartObj

def lab_home_chart(request):
    lab_users_chartObj = lab_users_chart()
    lab_objects_chartObj = lab_objects_chart()

    return render(request, 'home.html', {'lab_users_chartObj': lab_users_chartObj.render(), 'lab_objects_chartObj':lab_objects_chartObj.render()})